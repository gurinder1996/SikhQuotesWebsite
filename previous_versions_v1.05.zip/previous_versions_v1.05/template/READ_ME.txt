For how to setup, please open `documentation` folder at your web server.



Here is a fast setup step.

01. use /assets/js/variable.js to config function (choose version and function)

------------------------------

02. change the main color, open index.html find

theme_black_brown.css

change to (choose one of style below)

theme_black_red.css
theme_black_blue.css
theme_black_green.css
theme_black_pink.css
theme_black_orange.css
theme_black_purple.css
theme_black_brown.css

theme_dark_red.css
theme_dark_blue.css
theme_dark_green.css
theme_dark_pink.css
theme_dark_orange.css
theme_dark_purple.css
theme_dark_brown.css

------------------------------

03. for email, newsletter and other setting, please read documentation.

------------------------------

04. message me via EMAIL for any support, normally we will reply within two day, thank you :)